const greetBtn = document.getElementById('greetBtn');
const greeting = document.getElementById('greeting');

const messages = [
  "Hello! Kaise ho? 👋",
  "Aap ka din shubh ho! ☀️",
  "Thanks for visiting! ❤️",
  "Coding is fun! 💻"
];

greetBtn.addEventListener('click', () => {
  const randomMsg = messages[Math.floor(Math.random() * messages.length)];
  greeting.textContent = randomMsg;
  
  // 3 second baad message hat jaye
  setTimeout(() => {
    greeting.textContent = "";
  }, 3000);
});